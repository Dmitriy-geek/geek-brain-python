# задача 1
test = open("new file.txt", "w", encoding="utf-8")
n = "Привет тебе человек"
while n:
    line = input("Введите строку или просто Enter")
    n = test.write(f'{line}\n')
    if not line:
        break
test.close()


# задача 2
f = open('test.txt', 'r', encoding='utf-8')
c = 0
for line in f:
    print(line, end="")
    c += 1
    n = len(line)-1
    print(f'- количество символов - {n}')
print(f'Конец файла. Всего строк - {c}')
f.close()


# задача 3
with open('работнички.txt', 'r', encoding="utf-8") as my_file:
    sal = []
    poor = []
    my_list = my_file.read().split('\n')
    for i in my_list:
        i = i.split(',')
        c = int(i[1])
        if c < 20000:
            poor.append(i[0])
print(f'Оклад меньше 20.000 у {poor} \nCредня величина оклада {round(sum(map(int, sal)) / len(sal), 2)}')


# задача 4
trans = open('4.txt', 'r', encoding='utf-8')
sal = ""
my_list = trans.read().split('\n')
print(my_list)
for i in my_list:
    i = i.split(' ')
    с = ''
    c = i[0]
    if c == "One":
        i[0]= "Один"
    elif с == "Two":
        i[0]= "Два"
    elif с == "Three":
        i[0] = "Три"
    elif с == "Four":
        i[0] = "Четыре"

    sal = sal + ("".join(i)) + "\n"
print(sal)

four = open("new4.txt","w",encoding="utf-8")
four.write(str(sal))
four.close()

trans.close()

# задача 5

def summary():
    try:
        with open('file_5.txt', 'w+', encoding='utf-8') as file_obj:
            line = input('Введите цифры через пробел \n')
            file_obj.writelines(line)
            digit = line.split()

            print(sum(map(int, digit)))
    except IOError:
        print('Ошибка в файле')
    except ValueError:
        print('Вводите только цифры')
summary()
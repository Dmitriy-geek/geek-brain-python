# задача 1
test = open("new file.txt", "w", encoding="utf-8")
n = "Привет тебе человек"
while n:
    line = input("Введите строку или просто Enter")
    n = test.write(f'{line}\n')
    if not line:
        break
test.close()


# задача 2
f = open('test.txt', 'r', encoding='utf-8')
c = 0
for line in f:
    print(line, end="")
    c += 1
    n = len(line)-1
    print(f'- количество символов - {n}')
print(f'Конец файла. Всего строк - {c}')
f.close()


# задача 3
with open('работнички.txt', 'r', encoding="utf-8") as my_file:
    sal = []
    poor = []
    my_list = my_file.read().split('\n')
    for i in my_list:
        i = i.split(',')
        c = int(i[1])
        if c < 20000:
            poor.append(i[0])
print(f'Оклад меньше 20.000 у {poor} \nCредня величина оклада {round(sum(map(int, sal)) / len(sal), 2)}')


# задача 4
from googletrans import Translator
translator = Translator()

f = open('4.txt', 'r', encoding='utf-8')
contents = f.read()
result = translator.translate(contents, dest='ru')
print(result.text)

four = open("new4.txt","w",encoding="utf-8")
four.write(result.text)
four.close()

f.close()

# задача 5

def summary():
    try:
        with open('file_5.txt', 'w+', encoding='utf-8') as file_obj:
            line = input('Введите цифры через пробел \n')
            file_obj.writelines(line)
            digit = line.split()

            print(sum(map(int, digit)))
    except IOError:
        print('Ошибка в файле')
    except ValueError:
        print('Вводите только цифры')
summary()

# задача №6
def stop(n):  # это огромный блок вычленения чисел из строки
    s = n
    l = len(s)
    integ = []
    i = 0
    while i < l:
        s_int = ''
        a = s[i]
        while '0' <= a <= '9':
            s_int += a
            i += 1
            if i < l:
                a = s[i]
            else:
                break
        i += 1
        if s_int != '':
            integ.append(int(s_int))
    return (integ)


dict = {}
with open('text_6.txt', 'r', encoding="utf-8") as init_f:
    for line in init_f:
        print(line , end="")
        list_l = line.split(":")
        n = list_l[1]
        key = list_l[0]
        dict[key] = list_l[1]
        n = dict.get(key)
        m = stop(n) # выход на функцию
        summa = 0
        for k in m: # суммирование полученных значений
            summa = summa + k
        dict[key] = summa
print("")
print(dict)

# задача #7

import json
profit = {}
pr = {}
prof = 0
prof_aver = 0
i = 0
with open('text_7.txt', 'r', encoding="utf-8") as file:
    for line in file:
        name, firm, earning, damage = line.split()
        profit[name] = int(earning) - int(damage)
        if profit[name] >= 0:
            prof = prof + profit[name]
            i += 1
    if i != 0:
        prof_aver = prof / i
        print(f'Прибыль средняя - {prof_aver:.2f}')
    else:
        print(f'Прибыль средняя - отсутсвует. Все работают в убыток')
    pr = {'средняя прибыль': round(prof_aver)}
    profit.update(pr)
    print(f'Прибыль каждой компании - {profit}')

with open('file_7.json', 'w') as write_js:
    json.dump(profit, write_js)

    js_str = json.dumps(profit)
    print(f'Создан файл с расширением json со следующим содержимым: \n '
          f' {js_str}') 
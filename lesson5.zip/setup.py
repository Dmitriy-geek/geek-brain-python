from setuptools import setup

setup(
    name='git',
    version='',
    packages=[''],
    url='',
    license='',
    author='79650',
    author_email='',
    description=''
)
